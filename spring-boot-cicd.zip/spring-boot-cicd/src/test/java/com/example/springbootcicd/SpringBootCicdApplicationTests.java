package com.example.springbootcicd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCicdApplicationTests {

	@Test
	void contextLoads() {
	}

}
